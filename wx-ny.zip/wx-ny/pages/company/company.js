// pages/company/company.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    companyArr:[
      {
        id: 1,
        title: '西安市鑫丰种业有限公司',
        date: '2018-05-01',
        trade: '种子行业'
      }, {
        id: 2,
        title: '华县华寿生态农业有限公司',
        date: '2018-05-01',
        trade: '种子行业'
      }, {
        id: 3,
        title: '陕西荷丰农业开发有限公司',
        date: '2018-05-01',
        trade: '种子行业'
      }, {
        id: 4,
        title: '陕西盛农农资有限公司',
        date: '2018-05-01',
        trade: '种子行业'
      }, {
        id: 5,
        title: '陕西新华农农资有限公司',
        date: '2018-05-01',
        trade: '种子行业'
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})